# Notice

Fodium is a derivative work and is licensed under the **GNU Lesser General Public License v3.0 only** (`LICENSE`, with `COPYING` = GPL-3.0 which LGPL-3.0 references).

Based on:
- **Embeddium** by embeddedt — LGPL-3.0-only — https://github.com/embeddedt/embeddium
- **Sodium** by JellySquid (jellysquid3) / CaffeineMC — last LGPL-3.0 version
- Option screen code derived from **Reese's Sodium Options** by FlashyReese — MIT (`licenses/rso.txt`)

When you copy code from these projects, keep the original copyright headers and state your changes.
Fodium is not affiliated with or supported by Embeddium, CaffeineMC, Mojang or Microsoft.
