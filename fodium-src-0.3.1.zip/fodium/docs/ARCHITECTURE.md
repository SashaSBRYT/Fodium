# Architecture notes

Findings (Mojang 26.2 snapshots 1–2): vanilla now ships a Vulkan backend and a video-settings option
**Graphics API: Default / Prefer Vulkan / Prefer OpenGL** (fallback to the other if one fails;
needs Vulkan 1.2 + dynamic rendering + push descriptors). Fodium therefore does NOT write its own Vulkan
backend. It must:

1. **Settings UI** — add a "Graphics API" button to Fodium's (Sodium-style) video settings page, bound to
   vanilla's own option so the choice is honoured by vanilla (restart/reload likely required).
   Needs the exact option class/field in 26.2 sources.
2. **Port the chunk renderer** — Embeddium/Sodium call OpenGL directly (VAOs, glMultiDraw*, persistent
   buffers). That code cannot run on the Vulkan backend. It must be rewritten on top of vanilla's GPU
   abstraction (GpuDevice / RenderPipeline / GpuBuffer and render passes), implementing `ChunkRenderBackend`.
   This is the bulk of the work (region arenas, indirect/multi-draw equivalent, translucency sorting, culling).
3. **Shaders** — convert Sodium's GLSL to the vanilla pipeline/shader format (26.2 note: reversed depth buffer).
4. **Conflicts** — `fabric.mod.json` declares `breaks` on sodium/embeddium.

Next steps: obtain Embeddium sources (github.com/embeddedt/embeddium), set up a 26.2 dev environment,
read vanilla's `GpuDevice` implementations for both backends, port culling/meshing first (API-independent),
then the draw layer.
