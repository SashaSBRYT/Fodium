package dev.fodium;

import dev.fodium.config.FodiumConfig;
import dev.fodium.render.BackendSelector;
import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Fodium client entrypoint. Licensed under LGPL-3.0-only. */
public final class FodiumMod implements ClientModInitializer {
    public static final String MOD_ID = "fodium";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static FodiumConfig config;

    @Override
    public void onInitializeClient() {
        config = FodiumConfig.instance();
        LOGGER.info("Fodium: preferred graphics API = {}, render pass mode = {}", config.graphicsApi(), config.renderPassMode());
        // TODO: once the chunk renderer is ported, BackendSelector.select(...) is called
        // after vanilla has created its GpuDevice (see docs/ARCHITECTURE.md).
        BackendSelector.describe(config.graphicsApi());
    }

    public static FodiumConfig config() {
        return config;
    }
}
