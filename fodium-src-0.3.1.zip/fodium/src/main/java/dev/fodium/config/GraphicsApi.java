package dev.fodium.config;

/** Mirrors vanilla's "Graphics API" option: Default / Prefer Vulkan / Prefer OpenGL. */
public enum GraphicsApi {
    DEFAULT("fodium.option.graphics_api.default"),
    VULKAN("fodium.option.graphics_api.vulkan"),
    OPENGL("fodium.option.graphics_api.opengl");

    private final String translationKey;

    GraphicsApi(String translationKey) { this.translationKey = translationKey; }

    public String translationKey() { return translationKey; }

    public static GraphicsApi parse(String s) {
        for (GraphicsApi a : values()) if (a.name().equalsIgnoreCase(s)) return a;
        return DEFAULT;
    }
}
