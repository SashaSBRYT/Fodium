package dev.fodium.config;

/** How the Vulkan backend begins render passes. */
public enum RenderPassMode {
    /** Vanilla behaviour: VK_KHR_dynamic_rendering. */
    DYNAMIC,
    /** Classic VkRenderPass + VkFramebuffer (often friendlier to tiled GPUs such as Adreno). */
    CLASSIC;

    public static RenderPassMode parse(String s) {
        for (RenderPassMode m : values()) if (m.name().equalsIgnoreCase(s)) return m;
        return CLASSIC;
    }
}
