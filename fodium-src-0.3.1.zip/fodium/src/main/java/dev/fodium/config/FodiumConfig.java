package dev.fodium.config;

import dev.fodium.FodiumMod;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Minimal properties-file config (config/fodium.properties). */
public final class FodiumConfig {
    private static FodiumConfig instance;

    private GraphicsApi graphicsApi = GraphicsApi.DEFAULT;
    private RenderPassMode renderPassMode = RenderPassMode.CLASSIC;

    /** Lazily loaded: mixins may need this before the client entrypoint runs. */
    public static synchronized FodiumConfig instance() {
        if (instance == null) instance = load();
        return instance;
    }

    public GraphicsApi graphicsApi() { return graphicsApi; }
    public RenderPassMode renderPassMode() { return renderPassMode; }

    public void setGraphicsApi(GraphicsApi api) { this.graphicsApi = api; save(); }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("fodium.properties");
    }

    private static FodiumConfig load() {
        FodiumConfig c = new FodiumConfig();
        Path f = file();
        if (Files.exists(f)) {
            Properties p = new Properties();
            try (Reader r = Files.newBufferedReader(f)) {
                p.load(r);
                c.graphicsApi = GraphicsApi.parse(p.getProperty("graphics_api", "DEFAULT"));
                c.renderPassMode = RenderPassMode.parse(p.getProperty("render_pass", "CLASSIC"));
            } catch (IOException e) {
                FodiumMod.LOGGER.warn("Could not read {}", f, e);
            }
        } else {
            c.save();
        }
        return c;
    }

    public void save() {
        Properties p = new Properties();
        p.setProperty("graphics_api", graphicsApi.name());
        p.setProperty("render_pass", renderPassMode.name());
        try (Writer w = Files.newBufferedWriter(file())) {
            p.store(w, "Fodium configuration. render_pass = CLASSIC | DYNAMIC");
        } catch (IOException e) {
            FodiumMod.LOGGER.warn("Could not write config", e);
        }
    }
}
