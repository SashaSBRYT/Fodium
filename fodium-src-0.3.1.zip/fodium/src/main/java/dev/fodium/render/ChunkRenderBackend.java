package dev.fodium.render;

/**
 * API-agnostic contract for Fodium's Sodium-style chunk renderer. Implementations must
 * go through vanilla's GPU abstraction (not raw GL calls), so that they work on both
 * the OpenGL and Vulkan vanilla backends.
 */
public interface ChunkRenderBackend {
    String name();

    /** Create pipelines, buffers and arenas. Called once vanilla's GPU device exists. */
    void init();

    /** Release all GPU resources. */
    void close();

    // TODO: uploadSection(...), drawRegion(...), etc. See docs/ARCHITECTURE.md.
}
