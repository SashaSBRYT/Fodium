package dev.fodium.render;

import dev.fodium.FodiumMod;
import dev.fodium.config.GraphicsApi;

/** Chooses which API the user wants; the actual switch is performed by vanilla's backend. */
public final class BackendSelector {
    private BackendSelector() {}

    public static void describe(GraphicsApi api) {
        switch (api) {
            case VULKAN -> FodiumMod.LOGGER.info("Requested: Vulkan (vanilla falls back to OpenGL if unsupported)");
            case OPENGL -> FodiumMod.LOGGER.info("Requested: OpenGL (vanilla falls back to Vulkan if unsupported)");
            default -> FodiumMod.LOGGER.info("Requested: vanilla default");
        }
    }
}
