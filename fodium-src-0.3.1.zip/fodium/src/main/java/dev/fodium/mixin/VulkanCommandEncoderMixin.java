package dev.fodium.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.blaze3d.systems.RenderPassDescriptor;
import com.mojang.blaze3d.vulkan.Destroyable;
import com.mojang.blaze3d.vulkan.VulkanCommandEncoder;
import com.mojang.blaze3d.vulkan.VulkanDevice;
import dev.fodium.config.FodiumConfig;
import dev.fodium.config.RenderPassMode;
import dev.fodium.vulkan.ClassicRenderPass;
import org.lwjgl.vulkan.VK10;
import org.lwjgl.vulkan.VkCommandBuffer;
import org.lwjgl.vulkan.VkRenderingInfo;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(VulkanCommandEncoder.class)
public abstract class VulkanCommandEncoderMixin {
    @Shadow @org.spongepowered.asm.mixin.Final private VulkanDevice device;
    @Shadow public abstract void queueForDestroy(Destroyable destroyable);

    @WrapOperation(
        method = "createRenderPass",
        at = @At(value = "INVOKE",
            target = "Lorg/lwjgl/vulkan/KHRDynamicRendering;vkCmdBeginRenderingKHR(Lorg/lwjgl/vulkan/VkCommandBuffer;Lorg/lwjgl/vulkan/VkRenderingInfo;)V"))
    private void fodium$beginRenderPass(VkCommandBuffer cmd, VkRenderingInfo info, Operation<Void> original,
                                        @Local(argsOnly = true) RenderPassDescriptor descriptor) {
        if (FodiumConfig.instance().renderPassMode() == RenderPassMode.CLASSIC) {
            ClassicRenderPass.begin(this.device.vkDevice(), cmd, info, descriptor, this::queueForDestroy);
        } else {
            original.call(cmd, info);
        }
    }

    @WrapOperation(
        method = "submitRenderPass",
        at = @At(value = "INVOKE",
            target = "Lorg/lwjgl/vulkan/KHRDynamicRendering;vkCmdEndRenderingKHR(Lorg/lwjgl/vulkan/VkCommandBuffer;)V"))
    private void fodium$endRenderPass(VkCommandBuffer cmd, Operation<Void> original) {
        if (FodiumConfig.instance().renderPassMode() == RenderPassMode.CLASSIC) {
            ClassicRenderPass.end(cmd);
        } else {
            original.call(cmd);
        }
    }
}
