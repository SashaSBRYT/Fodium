package dev.fodium.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.mojang.blaze3d.vulkan.VulkanRenderPipeline;
import dev.fodium.config.FodiumConfig;
import dev.fodium.config.RenderPassMode;
import dev.fodium.vulkan.ClassicRenderPass;
import org.lwjgl.vulkan.VkAllocationCallbacks;
import org.lwjgl.vulkan.VkDevice;
import org.lwjgl.vulkan.VkGraphicsPipelineCreateInfo;
import org.lwjgl.vulkan.VkPipelineRenderingCreateInfoKHR;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.nio.LongBuffer;

@Mixin(VulkanRenderPipeline.class)
public abstract class VulkanRenderPipelineMixin {
    /**
     * Vanilla builds each pipeline against VkPipelineRenderingCreateInfoKHR (dynamic rendering).
     * For CLASSIC mode, build it against a compatible VkRenderPass instead. This matches both
     * vkCreateGraphicsPipelines calls in compile() (with-depth and without-depth variants).
     */
    @WrapOperation(
        method = "compile",
        at = @At(value = "INVOKE",
            target = "Lorg/lwjgl/vulkan/VK12;vkCreateGraphicsPipelines(Lorg/lwjgl/vulkan/VkDevice;JLorg/lwjgl/vulkan/VkGraphicsPipelineCreateInfo$Buffer;Lorg/lwjgl/vulkan/VkAllocationCallbacks;Ljava/nio/LongBuffer;)I"))
    private static int fodium$classicPipeline(VkDevice device, long cache, VkGraphicsPipelineCreateInfo.Buffer infos,
                                              VkAllocationCallbacks callbacks, LongBuffer out,
                                              Operation<Integer> original) {
        if (FodiumConfig.instance().renderPassMode() != RenderPassMode.CLASSIC) {
            return original.call(device, cache, infos, callbacks, out);
        }
        long pNext = infos.pNext();
        VkPipelineRenderingCreateInfoKHR r = VkPipelineRenderingCreateInfoKHR.create(pNext);
        long rp = ClassicRenderPass.compatibleFor(device, r);
        infos.renderPass(rp);
        infos.subpass(0);
        infos.pNext(0L);
        try {
            return original.call(device, cache, infos, callbacks, out);
        } finally {
            // vanilla mutates the rendering info and calls again for the no-depth variant
            infos.pNext(pNext);
            infos.renderPass(0L);
        }
    }
}
