package dev.fodium.vulkan;

import com.mojang.blaze3d.systems.RenderPassDescriptor;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vulkan.Destroyable;
import com.mojang.blaze3d.vulkan.VulkanConst;
import dev.fodium.FodiumMod;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.vulkan.*;

import java.nio.IntBuffer;
import java.nio.LongBuffer;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

import static org.lwjgl.vulkan.VK10.*;

/**
 * Replaces vanilla's VK_KHR_dynamic_rendering begin/end with a classic VkRenderPass + VkFramebuffer.
 *
 * Facts taken from the 26.2 bytecode (VulkanCommandEncoder#createRenderPass):
 *  - every attachment is used in VK_IMAGE_LAYOUT_GENERAL, so no layout transitions are needed;
 *  - null color attachments are allowed (slot with imageView == 0);
 *  - depth is optional; the pipelines are built with depth format 126 (D32_SFLOAT);
 *  - vanilla issues a full ALL_COMMANDS memory barrier after every pass.
 */
public final class ClassicRenderPass {
    private ClassicRenderPass() {}

    private static final Map<String, Long> CACHE = new HashMap<>();

    /** Get or create a render pass. Color format 0 means "unused slot"; depthFormat 0 means no depth. */
    public static long renderPass(VkDevice device, int[] colorFormats, int[] colorLoad, int[] colorStore,
                                  int depthFormat, int depthLoad, int depthStore) {
        StringBuilder k = new StringBuilder().append(device.address()).append('|');
        for (int i = 0; i < colorFormats.length; i++) {
            k.append(colorFormats[i]).append(',').append(colorLoad[i]).append(',').append(colorStore[i]).append(';');
        }
        k.append('|').append(depthFormat).append(',').append(depthLoad).append(',').append(depthStore);
        String key = k.toString();
        synchronized (CACHE) {
            Long cached = CACHE.get(key);
            if (cached != null) return cached;
            long rp = create(device, colorFormats, colorLoad, colorStore, depthFormat, depthLoad, depthStore);
            CACHE.put(key, rp);
            return rp;
        }
    }

    private static long create(VkDevice device, int[] colorFormats, int[] colorLoad, int[] colorStore,
                               int depthFormat, int depthLoad, int depthStore) {
        try (MemoryStack stack = MemoryStack.stackPush()) {
            int used = 0;
            for (int f : colorFormats) if (f != 0) used++;
            int total = used + (depthFormat != 0 ? 1 : 0);

            VkAttachmentDescription.Buffer atts = VkAttachmentDescription.calloc(Math.max(total, 1), stack);
            VkAttachmentReference.Buffer colorRefs = VkAttachmentReference.calloc(Math.max(colorFormats.length, 1), stack);

            int idx = 0;
            for (int i = 0; i < colorFormats.length; i++) {
                if (colorFormats[i] == 0) {
                    colorRefs.get(i).attachment(VK_ATTACHMENT_UNUSED).layout(VK_IMAGE_LAYOUT_UNDEFINED);
                } else {
                    atts.get(idx)
                        .format(colorFormats[i]).samples(VK_SAMPLE_COUNT_1_BIT)
                        .loadOp(colorLoad[i]).storeOp(colorStore[i])
                        .stencilLoadOp(VK_ATTACHMENT_LOAD_OP_DONT_CARE).stencilStoreOp(VK_ATTACHMENT_STORE_OP_DONT_CARE)
                        .initialLayout(VK_IMAGE_LAYOUT_GENERAL).finalLayout(VK_IMAGE_LAYOUT_GENERAL);
                    colorRefs.get(i).attachment(idx).layout(VK_IMAGE_LAYOUT_GENERAL);
                    idx++;
                }
            }

            VkAttachmentReference depthRef = null;
            if (depthFormat != 0) {
                atts.get(idx)
                    .format(depthFormat).samples(VK_SAMPLE_COUNT_1_BIT)
                    .loadOp(depthLoad).storeOp(depthStore)
                    .stencilLoadOp(VK_ATTACHMENT_LOAD_OP_DONT_CARE).stencilStoreOp(VK_ATTACHMENT_STORE_OP_DONT_CARE)
                    .initialLayout(VK_IMAGE_LAYOUT_GENERAL).finalLayout(VK_IMAGE_LAYOUT_GENERAL);
                depthRef = VkAttachmentReference.calloc(stack).attachment(idx).layout(VK_IMAGE_LAYOUT_GENERAL);
            }

            VkSubpassDescription.Buffer subpass = VkSubpassDescription.calloc(1, stack)
                .pipelineBindPoint(VK_PIPELINE_BIND_POINT_GRAPHICS)
                .colorAttachmentCount(colorFormats.length)
                .pColorAttachments(colorFormats.length == 0 ? null : colorRefs)
                .pDepthStencilAttachment(depthRef);

            // Vanilla already uses full barriers around passes; mirror that, BY_REGION for tilers.
            VkSubpassDependency.Buffer deps = VkSubpassDependency.calloc(2, stack);
            deps.get(0).srcSubpass(VK_SUBPASS_EXTERNAL).dstSubpass(0)
                .srcStageMask(VK_PIPELINE_STAGE_ALL_COMMANDS_BIT).dstStageMask(VK_PIPELINE_STAGE_ALL_GRAPHICS_BIT)
                .srcAccessMask(VK_ACCESS_MEMORY_WRITE_BIT)
                .dstAccessMask(VK_ACCESS_MEMORY_READ_BIT | VK_ACCESS_MEMORY_WRITE_BIT)
                .dependencyFlags(VK_DEPENDENCY_BY_REGION_BIT);
            deps.get(1).srcSubpass(0).dstSubpass(VK_SUBPASS_EXTERNAL)
                .srcStageMask(VK_PIPELINE_STAGE_ALL_GRAPHICS_BIT).dstStageMask(VK_PIPELINE_STAGE_ALL_COMMANDS_BIT)
                .srcAccessMask(VK_ACCESS_MEMORY_WRITE_BIT)
                .dstAccessMask(VK_ACCESS_MEMORY_READ_BIT | VK_ACCESS_MEMORY_WRITE_BIT)
                .dependencyFlags(VK_DEPENDENCY_BY_REGION_BIT);

            VkRenderPassCreateInfo ci = VkRenderPassCreateInfo.calloc(stack)
                .sType$Default()
                .pAttachments(total == 0 ? null : atts)
                .pSubpasses(subpass)
                .pDependencies(deps);

            LongBuffer out = stack.mallocLong(1);
            int res = vkCreateRenderPass(device, ci, null, out);
            if (res != VK_SUCCESS) throw new IllegalStateException("Fodium: vkCreateRenderPass failed: " + res);
            return out.get(0);
        }
    }

    /** Replacement for vkCmdBeginRenderingKHR(cmd, info). */
    public static void begin(VkDevice device, VkCommandBuffer cmd, VkRenderingInfo info,
                             RenderPassDescriptor desc, Consumer<Destroyable> destroyLater) {
        try (MemoryStack stack = MemoryStack.stackPush()) {
            int colorCount = info.colorAttachmentCount();
            VkRenderingAttachmentInfo.Buffer colors = info.pColorAttachments();
            VkRenderingAttachmentInfo depth = info.pDepthAttachment();

            int[] fmt = new int[colorCount], load = new int[colorCount], store = new int[colorCount];
            int used = 0;
            for (int i = 0; i < colorCount; i++) {
                VkRenderingAttachmentInfo a = colors.get(i);
                if (a.imageView() == 0L) { fmt[i] = 0; continue; }
                GpuTextureView view = desc.colorAttachments().get(i).textureView();
                fmt[i] = VulkanConst.toVk(view.texture().getFormat());
                load[i] = a.loadOp();
                store[i] = a.storeOp();
                used++;
            }
            int depthFmt = 0, depthLoad = 0, depthStore = 0;
            if (depth != null) {
                depthFmt = VulkanConst.toVk(desc.depthAttachment().textureView().texture().getFormat());
                depthLoad = depth.loadOp();
                depthStore = depth.storeOp();
            }

            long rp = renderPass(device, fmt, load, store, depthFmt, depthLoad, depthStore);

            int total = used + (depth != null ? 1 : 0);
            LongBuffer views = stack.mallocLong(Math.max(total, 1));
            VkClearValue.Buffer clears = VkClearValue.calloc(Math.max(total, 1), stack);
            int idx = 0;
            for (int i = 0; i < colorCount; i++) {
                VkRenderingAttachmentInfo a = colors.get(i);
                if (a.imageView() == 0L) continue;
                views.put(idx, a.imageView());
                if (a.loadOp() == VK_ATTACHMENT_LOAD_OP_CLEAR) clears.get(idx).set(a.clearValue());
                idx++;
            }
            if (depth != null) {
                views.put(idx, depth.imageView());
                if (depth.loadOp() == VK_ATTACHMENT_LOAD_OP_CLEAR) clears.get(idx).set(depth.clearValue());
                idx++;
            }

            VkRect2D area = info.renderArea();
            int fbW = area.offset().x() + area.extent().width();
            int fbH = area.offset().y() + area.extent().height();

            VkFramebufferCreateInfo fci = VkFramebufferCreateInfo.calloc(stack)
                .sType$Default()
                .renderPass(rp)
                .pAttachments(views.limit(total))
                .width(fbW).height(fbH).layers(1);
            LongBuffer pFb = stack.mallocLong(1);
            int res = vkCreateFramebuffer(device, fci, null, pFb);
            if (res != VK_SUCCESS) throw new IllegalStateException("Fodium: vkCreateFramebuffer failed: " + res);
            long fb = pFb.get(0);
            destroyLater.accept(() -> vkDestroyFramebuffer(device, fb, null));

            VkRenderPassBeginInfo bi = VkRenderPassBeginInfo.calloc(stack)
                .sType$Default()
                .renderPass(rp)
                .framebuffer(fb)
                .renderArea(area)
                .pClearValues(total == 0 ? null : clears.limit(total));
            vkCmdBeginRenderPass(cmd, bi, VK_SUBPASS_CONTENTS_INLINE);
        } catch (RuntimeException e) {
            FodiumMod.LOGGER.error("Fodium: classic render pass begin failed. Set render_pass=DYNAMIC in config/fodium.properties", e);
            throw e;
        }
    }

    public static void end(VkCommandBuffer cmd) {
        vkCmdEndRenderPass(cmd);
    }

    /** Render pass compatible with a pipeline, built from its VkPipelineRenderingCreateInfo. */
    public static long compatibleFor(VkDevice device, VkPipelineRenderingCreateInfoKHR r) {
        int n = r.colorAttachmentCount();
        IntBuffer f = r.pColorAttachmentFormats();
        int[] fmt = new int[n], load = new int[n], store = new int[n];
        for (int i = 0; i < n; i++) {
            fmt[i] = f.get(i);
            load[i] = VK_ATTACHMENT_LOAD_OP_LOAD;
            store[i] = VK_ATTACHMENT_STORE_OP_STORE;
        }
        int d = r.depthAttachmentFormat();
        return renderPass(device, fmt, load, store, d, VK_ATTACHMENT_LOAD_OP_LOAD, VK_ATTACHMENT_STORE_OP_STORE);
    }
}
