# Fodium (alpha)

LGPL-3.0-only. Fabric mod for Minecraft 26.2.

## What works in this version (untested - not compiled here)
**Classic render pass mode for the vanilla Vulkan backend.** Vanilla 26.2 begins render passes with
`VK_KHR_dynamic_rendering`. Fodium replaces that, via mixins into `VulkanCommandEncoder` and
`VulkanRenderPipeline`, with a classic `VkRenderPass` + `VkFramebuffer` (created per pass, destroyed via
vanilla's destruction queue; render pass objects are cached).

Config: `config/fodium.properties`
```
render_pass=CLASSIC   # or DYNAMIC to get vanilla behaviour back
graphics_api=DEFAULT
```
If the game crashes at startup, set `render_pass=DYNAMIC` (or remove the mod) and send `latest.log`.

**No dynamic_rendering requirement in CLASSIC mode (0.3).** `VulkanBackendMixin` removes `VK_KHR_dynamic_rendering`
from vanilla's required extensions/features, so GPUs without it (for example Radeon R7 350 on AMD 22.6.1,
Vulkan 1.2) are no longer rejected. push_descriptor, synchronization2, vertex_attribute_divisor,
timeline semaphores, hostQueryReset and Vulkan 1.2 are still required by vanilla.

## Not implemented
Sodium-style chunk renderer, in-game Graphics API button. See docs/ARCHITECTURE.md.

## Build
Fill versions in `gradle.properties` (https://fabricmc.net/develop), add the Gradle wrapper, `./gradlew build` (Java 25).
