package dev.fodium.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.mojang.blaze3d.vulkan.VulkanBackend;
import com.mojang.blaze3d.vulkan.init.VulkanFeature;
import dev.fodium.FodiumMod;
import dev.fodium.config.FodiumConfig;
import dev.fodium.config.RenderPassMode;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.HashSet;
import java.util.Set;

/**
 * In CLASSIC mode we never call VK_KHR_dynamic_rendering, so vanilla must not demand it.
 * Without this, GPUs/drivers lacking the extension (e.g. Radeon R7 350 on AMD 22.6.1) are rejected
 * before rendering even starts. Vanilla 26.2 REQUIRED_DEVICE_EXTENSIONS / REQUIRED_DEVICE_FEATURES
 * are built in VulkanBackend.<clinit>; we filter the values as they are stored.
 */
@Mixin(VulkanBackend.class)
public abstract class VulkanBackendMixin {
    private static final String DYNAMIC_RENDERING_EXT = "VK_KHR_dynamic_rendering";
    /** sType of VkPhysicalDeviceDynamicRenderingFeatures (read from vanilla bytecode: 1000044003). */
    private static final int DYNAMIC_RENDERING_FEATURES_STYPE = 1000044003;

    @WrapOperation(
        method = "<clinit>",
        at = @At(value = "FIELD", opcode = 179 /* PUTSTATIC */,
            target = "Lcom/mojang/blaze3d/vulkan/VulkanBackend;REQUIRED_DEVICE_EXTENSIONS:Ljava/util/Set;"))
    private static void fodium$relaxExtensions(Set<String> value, Operation<Void> original) {
        if (FodiumConfig.instance().renderPassMode() == RenderPassMode.CLASSIC) {
            Set<String> copy = new HashSet<>(value);
            if (copy.remove(DYNAMIC_RENDERING_EXT)) {
                FodiumMod.LOGGER.info("Fodium: {} is no longer required (classic render pass mode)", DYNAMIC_RENDERING_EXT);
            }
            original.call(Set.copyOf(copy));
        } else {
            original.call(value);
        }
    }

    @WrapOperation(
        method = "<clinit>",
        at = @At(value = "FIELD", opcode = 179 /* PUTSTATIC */,
            target = "Lcom/mojang/blaze3d/vulkan/VulkanBackend;REQUIRED_DEVICE_FEATURES:Ljava/util/Set;"))
    private static void fodium$relaxFeatures(Set<VulkanFeature> value, Operation<Void> original) {
        if (FodiumConfig.instance().renderPassMode() == RenderPassMode.CLASSIC) {
            Set<VulkanFeature> copy = new HashSet<>(value);
            copy.removeIf(f -> f.struct().sType() == DYNAMIC_RENDERING_FEATURES_STYPE);
            original.call(Set.copyOf(copy));
        } else {
            original.call(value);
        }
    }
}
